# 颜色转换与可读性对比

独立插件 ID：`x_color`，版本 1.0.0，适配 Yukino Core 0.4.0 普通 worker。

HEX/RGB/HSL转换、亮度和WCAG文字对比度计算。完全离线，命令不调用模型，不读取聊天历史或服务器秘密。

## 使用

命令：`/颜色`、`/对比度`。

颜色格式支持 #RGB、#RRGGBB、rgb(r,g,b)。对比度使用 sRGB 相对亮度计算，显示 AA/AAA 普通文字及 AA 大号文字门槛。

示例：

```text
/对比度 #000000|#ffffff
```

## 面板配置

- `max_output_chars`：单次回复最多字符；默认 `6000`。

所有输入都有长度/数值边界，错误返回普通说明。无持久化、无网络、无任意路径读写。输出超限会明确注明截断。

## 打包

由扩展包构建器把本目录的 plugin.json、worker.py、README.md 与 dev_tools/dev_engine.py（改名为 _engine.py）放在同一插件 ZIP 根目录。源码开发时 worker 可回退加载共享 dev_engine.py。不要省略 _engine.py；此共享 helper 不是额外插件，不计入插件数量。
