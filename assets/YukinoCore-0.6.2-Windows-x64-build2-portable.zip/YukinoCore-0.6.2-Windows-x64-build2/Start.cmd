@echo off
cd /d "%~dp0"
"%~dp0runtime\python.exe" -X utf8 "%~dp0windows\launcher.py" start
if errorlevel 1 pause
