# Yukino Core 119 插件合集

适用 Yukino Core 0.6.3，含社区 11、麦麦功能参考 15、实用扩展 63、市场扩展 8、互动扩展 12、社交扩展 10 项。

解压后，在控制台「插件管理 → 从本地 ZIP 安装」选择各组目录下的单插件 ZIP，再启用。不要将本合集外层 ZIP 或带 source 的开发源码 ZIP 当作插件安装。Windows 便携版已自动捆绑这些插件。社交扩展中的 GitHub / 包版本联网查询，手动安装须先设置执行超时20秒；其他配置见各插件说明。

plugin-catalog.json 列出每项 ID、指令、包位置和 SHA-256；plugin-help 中是每项用法。各单插件保留 LICENSE / NOTICE，不能直接用于 MaiBot / AstrBot。联网功能按说明配置自己的服务。

[仓库与完整指南](https://github.com/Le672/yukino-core) · [插件开发](https://github.com/Le672/yukino-core/blob/main/docs/PLUGIN_AUTHORING.md)
